﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09._29_Balogh_Zoltán
{
    class Program
    {
        static void Main(string[] args)
        {
             /*1.feladat*/
             /*
             Console.WriteLine("Bankjegyautomata");
             Console.WriteLine("A legkisebb címlet 1000 Ft,a maximálisan felvehető összeg 300.000 Ft.");
             Console.WriteLine("Adja meg mekkora összeget kíván felvenni!");
             int osszeg = Convert.ToInt32(Console.ReadLine());
             int ezres = osszeg / 1000;
            int otezres =(osszeg-ezres)/5000;
            int tizezres =osszeg/10000;
            if (osszeg < 1000 && osszeg > 300000)
            {
                Console.WriteLine("Kérem adjon meg egy összeget 1000 és 300.000 forint között!");
            }
            else
            {
                Console.WriteLine("Kérem adjon meg egy másik számot!");
            }
            
            
            
            Console.WriteLine("A kiadott bankjegyek:"+ezres+"*1000");
            Console.WriteLine(otezres+"*5000 ");
            Console.WriteLine(tizezres+"*10000");
             */


            /*2.feladat*/
            /*
            Console.WriteLine("Utazási költségtérítés");
            Console.WriteLine("Add meg az utat km-ben!");
            int ut = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Add meg az auto fogyasztását literben 100 km-re!");
            Double benzin = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Add meg az üzemanyag árát ft-ban!");
            int penz = Convert.ToInt32(Console.ReadLine());
            Double uzemanyagkoltseg = (ut*benzin*penz)/100;
            if (ut < 100)
            {
                Console.WriteLine("A visszatérítés összege:" +uzemanyagkoltseg);

            }
            if (ut > 100)
            {
                Console.WriteLine("A költségtérítés:" +uzemanyagkoltseg+(ut*25));
            }
            */
            
            /*3.feladat*/
            
            Console.WriteLine("Kérem adja meg magasságát cm-ben:");
            double magassag = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Kérem adja meg a súlyát:");
            Double suly = Convert.ToDouble(Console.ReadLine()) ;
            double testindex = suly/(magassag*magassag);
            Console.WriteLine("A testömegindexe:"+testindex);
            
            Console.ReadLine();
        }
    }
}
